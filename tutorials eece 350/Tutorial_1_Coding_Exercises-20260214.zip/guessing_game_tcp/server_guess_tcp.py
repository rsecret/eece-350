import socket
import numpy as np

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((SERVER_IP, SERVER_PORT))
server.listen() 

def generate():
    g = np.random.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    return g

print("TCP Server is running, waiting for connection...")
conn, address = server.accept()
print(f"Connected to {address}")

g = generate()
conn.send("Ok, let's play! Make a guess of a number I chose between 0 and 10".encode('utf-8'))
count=10
while True:
    message = conn.recv(1024).decode('utf-8')
    if int(message) == g:
        msg="You won !,Play again? (YES,NO) Your final score is "+ str(count) +"/10"
        conn.send(msg.encode('utf-8'))
        message = conn.recv(1024).decode('utf-8')
        if message == "YES":
            count=10
            conn.send("Ok, let's play! Make a guess of a number I chose between 0 and 10".encode('utf-8'))
            g = generate()
        else:
            conn.send("Your loss".encode('utf-8'))
            break
    else:
        count-=1
        if count == 0:
            conn.send(f"No more tries. You lost! The number was {g}. Play again? (YES/NO)".encode('utf-8'))
            ans = conn.recv(1024).decode("utf-8").strip().upper()

            if ans == "YES":
                count = 10
                g = generate()
                conn.send("New round! Guess a number between 0 and 10.".encode("utf-8"))
            else:
                conn.send("Thanks for playing!".encode("utf-8"))
                break
        else:
            conn.send("Try again".encode('utf-8'))

conn.close()
server.close()
