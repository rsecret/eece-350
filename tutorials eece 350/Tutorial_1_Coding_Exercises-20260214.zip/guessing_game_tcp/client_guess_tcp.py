import socket

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = (SERVER_IP, SERVER_PORT)

client.connect(server_address)  # Connect to the server

message = client.recv(1024).decode('utf-8')
print(message)

while True:
    guess = input("Enter your guess (a number between 0 and 10): ")
    client.send(guess.encode('utf-8'))
    message = client.recv(1024).decode('utf-8')
    print(message)
    
    if "Play again?" in message:
        answer = input("Play again? (YES/NO): ").strip().upper()
        client.sendall(answer.encode("utf-8"))

        message = client.recv(1024).decode("utf-8")
        print(message)

        if answer != "YES":
            break

client.close()
