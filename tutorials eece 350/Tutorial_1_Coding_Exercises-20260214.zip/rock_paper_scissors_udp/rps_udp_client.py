import socket
import time

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
SERVER_IP = socket.gethostbyname(socket.gethostname())

SERVER_PORT = 8000

option = input("Choose between rock, paper, or scissors: ")
start = time.time()

client.sendto(option.encode('utf-8'), (SERVER_IP, SERVER_PORT))
result, addr = client.recvfrom(1024)
end = time.time()
print("Server response: " + result.decode('utf-8'))
print("RTT is: " + str(end-start) + " seconds")
