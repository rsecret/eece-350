import socket
import random

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

server.bind((socket.gethostbyname(socket.gethostname()), 8000))

options = ["rock", "paper", "scissors"]

print("=== UDP Rock-Paper-Scissors Server Started ===")
print("Waiting for client messages...\n")

while True:
    client_data, address = server.recvfrom(1024)  # waiting to receive a message from a user
    client_option = client_data.decode('utf-8').lower()

    print(f"[RECEIVED] From {address}: {client_option}")

    selected_option = random.choice(options)
    if selected_option == client_option:
        result = "It's a tie"
    elif selected_option == "rock":
        if client_option == "paper":
            result = "You win"
        else:
            result = "You lose"
    elif selected_option == "paper":
        if client_option == "scissors":
            result = "You win"
        else:
            result = "You lose"
    elif selected_option == "scissors":
        if client_option == "rock":
            result = "You win"
        else:
            result = "You lose"
    else:
        result = "You lose"

    response = f"{result}. Server chose {selected_option}"
    server.sendto(response.encode('utf-8'), address)
    print(f"[SENT] To {address}: {response}\n")
