import socket

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # creating stream socket
server.bind((SERVER_IP, SERVER_PORT))  # binding the server

server.listen()  # server listens for connections

print("TCP SERVER STARTED...")
print(f"Listening on {SERVER_IP}:{SERVER_PORT}")
print("Waiting for a client to connect...\n")


while True:
    conn, addr = server.accept()  # accept request for connection, returns connection object and address of client
    print("Client connected!")
    print(f"Client address: {addr}")
    msg = conn.recv(1024)  # using connection object to receive message from client
    decoded_msg = msg.decode('utf-8')

    print(f"Received from client: {decoded_msg}")
    reply = decoded_msg.upper()
    conn.send(reply.encode('utf-8'))  # changing message to uppercase, encode it, and send it to client

    print(f"Sending back (uppercase): {reply}\n")
    conn.close()  # closing the connection once done
    print("Connection closed")