import socket

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

print("Connecting to server...")
client.connect((SERVER_IP, SERVER_PORT))
print(f"Connected to {SERVER_IP}:{SERVER_PORT}\n")

message = input("Enter a string:")
client.send(message.encode('utf-8'))
print("Sending message to server...")

response = client.recv(1024)
print("Server replied:", response.decode("utf-8"))
