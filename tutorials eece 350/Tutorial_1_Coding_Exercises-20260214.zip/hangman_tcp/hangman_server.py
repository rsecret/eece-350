import socket
import random

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((socket.gethostbyname(socket.gethostname()), 8001))

words = ["karting", "engineering", "computer", "software", "mechanical"]


def handle_client(conn, addr):
    word = words[random.randint(0, len(words)-1)]
    print("Selected word:", word)
    letter_array = ['*']*len(word)

    # Dictionary to store letter positions. Example: {'o': [1, 4]}
    indexes = {}
    for i in range(len(word)):
        if word[i] not in indexes:
            indexes[word[i]] = [i]
        else:
            indexes[word[i]].append(i)
    chances = 7
    while chances > 0:
        letter = conn.recv(1024).decode('utf-8').lower()
        result = ""
        if letter in indexes:
            for x in indexes[letter]:
                letter_array[x] = letter
            result = "Letter in the word. Current progress: " + "".join(letter_array)
            if '*' not in letter_array:
                result += '\nYou win!'
                conn.send(result.encode('utf-8'))
                break
        else:
            result = "Letter not in the word. Remaining chances: " + str(chances-1) + " Current progress: " +\
                     "".join(letter_array)
            chances -= 1
            if chances == 0:
                result += '\nYou lose!'
                conn.send(result.encode('utf-8'))
                break
        conn.send(result.encode('utf-8'))
    conn.close()


server.listen()
while True:
    conn, addr = server.accept()
    handle_client(conn, addr)
