import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((socket.gethostbyname(socket.gethostname()), 8001))

while True:
    letter = input('Enter a letter: ')
    client.send(letter.encode('utf-8'))
    response = client.recv(1024).decode('utf-8')
    print(response)
    if "You win!" in response or "You lose!" in response:
        break

