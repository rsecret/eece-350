import socket

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((SERVER_IP, SERVER_PORT))

print("UDP SERVER STARTED...")
print(f"Listening on {SERVER_IP}:{SERVER_PORT}")
print("Waiting for incoming messages...\n")

while True:
    message, address = server.recvfrom(1024)  # receiving a message from a client and storing the address

    print(f"[RECEIVED] Message from {address}")
    print(f"Data: {message.decode('utf-8')}")

    server.sendto("Hello Client!".encode('utf-8'), address)  # replying to the user, specifying the address

    print(f"[SENT] Response sent to {address}\n")
