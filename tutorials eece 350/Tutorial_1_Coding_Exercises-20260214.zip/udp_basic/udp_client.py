import socket
import time

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

message = input("Enter your message: ")
start = time.time()

client.sendto(message.encode('utf-8'), (SERVER_IP, SERVER_PORT))

message, addr = client.recvfrom(1024)  # receiving reply from server

end = time.time()

print("Server response is: " + message.decode('utf-8'))

print("RTT is: " + str(end-start) + " seconds")
