import socket
import threading
import random

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # creating stream socket

server.bind((SERVER_IP, SERVER_PORT))  # binding the server

print("Multithreaded TCP Server Started..")
print(f"Server running on {SERVER_IP}:{SERVER_PORT}")
print("Waiting for incoming client connections...\n")

def handle_client(connection, address):
    while True:  # we keep playing with the server until client sends message DISCONNECT
        client_option = connection.recv(1024).decode('utf-8')
        if client_option == "DISCONNECT":
            break

        selected_option = random.choice(["rock", "paper", "scissors"])
        
        print(f"[RECEIVED] From {address}: {client_option}")

        if selected_option == client_option:
            result = "It's a tie"
        elif selected_option == "rock":
            if client_option == "paper":
                result = "You win"
            else:
                result = "You lose"
        elif selected_option == "paper":
            if client_option == "scissors":
                result = "You win"
            else:
                result = "You lose"
        elif selected_option == "scissors":
            if client_option == "rock":
                result = "You win"
            else:
                result = "You lose"
        else:
            result = "You lose"

        response = f"{result}. Server chose {selected_option}"
        connection.send(response.encode('utf-8'))

    connection.send("Closing connection".encode('utf-8'))
    print(f"[{address}] Disconnecting client")
    connection.close()


print("[Starting]")
server.listen()  # server listens for connections

while True:
    conn, addr = server.accept()  # accept request for connection, returns connection object and address of client
    print("Connection established. Address of client", addr)
    thread = threading.Thread(target=handle_client, args=(conn, addr))
    thread.start()
    print("Number of active threads:", threading.activeCount()-1)
