import socket

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((SERVER_IP, SERVER_PORT))

run = True
while run:  # we keep playing with the server until client sends message DISCONNECT
    message = input("Choose rock, paper, or scissors (type DISCONNECT to quit): ")
    if message == "DISCONNECT":
        run = False  # we don't break as we need to send DISCONNECT and expect the server to send Closing Connection
    client.send(message.encode('utf-8'))
    response = client.recv(1024)
    print(response.decode('utf-8'))
