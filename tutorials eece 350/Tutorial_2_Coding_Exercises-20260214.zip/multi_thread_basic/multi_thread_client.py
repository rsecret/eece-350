import socket
import time

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # creating the client socket
client.connect((SERVER_IP, SERVER_PORT))

message = input("Enter your message: ")
start = time.time()
client.send(message.encode('utf-8'))  # sending a message to the server

received = client.recv(1024)  # receiving reply from server
end = time.time()
print("Received message is: " + received.decode('utf-8'))
print("RTT is: " + str(end-start) + " seconds")
