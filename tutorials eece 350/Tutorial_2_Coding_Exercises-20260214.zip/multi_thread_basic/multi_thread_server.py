import socket
import threading

SERVER_IP = socket.gethostbyname(socket.gethostname())
SERVER_PORT = 8000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((SERVER_IP, SERVER_PORT))

print("Multithreaded TCP Server Started..")
print(f"Server running on {SERVER_IP}:{SERVER_PORT}")
print("Waiting for incoming client connections...\n")


def handle_client(connection, address):
    message = connection.recv(1024) # receiving a message from a client
    print(f"[Received from {address}] {message.decode('utf-8')}")
    connection.send("Hello user".encode('utf-8')) # replying to the user
    print(f"[Closing connection with {address}]")
    connection.close()


server.listen()
while True:
    conn, addr = server.accept()
    print("Connection established. Address of client", addr)
    thread = threading.Thread(target=handle_client, args=(conn, addr))
    thread.start()
    print("Number of active threads:", threading.active_count() - 1)
